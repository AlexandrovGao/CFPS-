<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="glass.css" />
    <title>Document</title>
<style type="text/css">
html,body,table,tr,td,input{ 
    margin:0; 
    padding:0;
}
a{ 
    color:white; 
    text-decoration:none;
}
</style>
</head>

<body>
	<div class="glass">
	<ul>
        <li><a href="connect.php">链接测试</a></li>
        <li><a href="page02.php">数据可视化</a></li>
        <li><a href="page03.php">MySQL命令提示符</a></li>
        <li><a href="index.php">重新加载</a></li>
    </ul>
	</div>
</body>
</html>
