export declare function registerImpl(name: string, impl: any): void;
export declare function getImpl(name: string): any;
