import GlobalModel from '../model/Global.js';
import ExtensionAPI from '../core/ExtensionAPI.js';
declare function barLayoutPolar(seriesType: string, ecModel: GlobalModel, api: ExtensionAPI): void;
export default barLayoutPolar;
