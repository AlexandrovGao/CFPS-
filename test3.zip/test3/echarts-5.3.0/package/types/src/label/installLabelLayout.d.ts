import { EChartsExtensionInstallRegisters } from '../extension.js';
export declare function installLabelLayout(registers: EChartsExtensionInstallRegisters): void;
