import Element from 'zrender/lib/Element.js';
export declare function findEventDispatcher(target: Element, det: (target: Element) => boolean, returnFirstMatch?: boolean): Element<import("zrender/lib/Element").ElementProps>;
