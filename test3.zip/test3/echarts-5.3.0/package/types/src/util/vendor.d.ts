export declare function createFloat32Array(arg: number | number[]): number[] | Float32Array;
