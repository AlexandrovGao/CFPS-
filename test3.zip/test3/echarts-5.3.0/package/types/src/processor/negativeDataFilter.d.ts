import { StageHandler } from '../util/types.js';
export default function negativeDataFilter(seriesType: string): StageHandler;
