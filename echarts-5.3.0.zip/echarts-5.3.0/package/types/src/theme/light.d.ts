declare const _default: {
    color: string[];
    colorLayer: string[][];
};
export default _default;
