import { EChartsExtensionInstallRegisters } from '../extension.js';
export declare function install(registers: EChartsExtensionInstallRegisters): void;
