import { ECUnitOption } from '../util/types.js';
export default function globalBackwardCompat(option: ECUnitOption, isTheme?: boolean): void;
