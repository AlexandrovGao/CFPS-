import { StageHandler } from '../util/types.js';
declare const seriesSymbolTask: StageHandler;
declare const dataSymbolTask: StageHandler;
export { seriesSymbolTask, dataSymbolTask };
