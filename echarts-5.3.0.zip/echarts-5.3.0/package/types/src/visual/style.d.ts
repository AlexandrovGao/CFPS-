import { StageHandler } from '../util/types.js';
declare const seriesStyleTask: StageHandler;
declare const dataStyleTask: StageHandler;
declare const dataColorPaletteTask: StageHandler;
export { seriesStyleTask, dataStyleTask, dataColorPaletteTask };
