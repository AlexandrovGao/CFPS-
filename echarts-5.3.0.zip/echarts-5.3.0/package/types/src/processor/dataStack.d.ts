import GlobalModel from '../model/Global.js';
export default function dataStack(ecModel: GlobalModel): void;
