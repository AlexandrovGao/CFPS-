import { StageHandler } from '../util/types.js';
export default function dataFilter(seriesType: string): StageHandler;
