import { StageHandler } from '../util/types.js';
export default function dataSample(seriesType: string): StageHandler;
