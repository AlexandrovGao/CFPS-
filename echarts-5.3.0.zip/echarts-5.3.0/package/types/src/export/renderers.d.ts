export { install as SVGRenderer } from '../renderer/installSVGRenderer.js';
export { install as CanvasRenderer } from '../renderer/installCanvasRenderer.js';
