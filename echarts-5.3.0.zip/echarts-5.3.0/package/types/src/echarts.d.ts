export * from './export/core.js';
declare const _default: {
    init(): import("./core/echarts").EChartsType;
};
export default _default;
