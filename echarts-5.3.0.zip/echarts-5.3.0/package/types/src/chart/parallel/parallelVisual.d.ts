import { StageHandler } from '../../util/types.js';
declare const parallelVisual: StageHandler;
export default parallelVisual;
