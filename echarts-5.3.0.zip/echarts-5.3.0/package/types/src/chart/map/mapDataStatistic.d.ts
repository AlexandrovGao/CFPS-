import GlobalModel from '../../model/Global.js';
export default function mapDataStatistic(ecModel: GlobalModel): void;
