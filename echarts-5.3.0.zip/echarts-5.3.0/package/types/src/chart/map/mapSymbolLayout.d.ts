import GlobalModel from '../../model/Global.js';
export default function mapSymbolLayout(ecModel: GlobalModel): void;
