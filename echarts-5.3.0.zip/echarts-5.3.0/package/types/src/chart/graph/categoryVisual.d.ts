import GlobalModel from '../../model/Global.js';
export default function categoryVisual(ecModel: GlobalModel): void;
