import GlobalModel from '../../model/Global.js';
export default function sunburstVisual(ecModel: GlobalModel): void;
