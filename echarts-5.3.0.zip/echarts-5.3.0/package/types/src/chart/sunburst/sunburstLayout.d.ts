import GlobalModel from '../../model/Global.js';
import ExtensionAPI from '../../core/ExtensionAPI.js';
export default function sunburstLayout(seriesType: 'sunburst', ecModel: GlobalModel, api: ExtensionAPI): void;
