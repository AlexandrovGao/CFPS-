import GlobalModel from '../../model/Global.js';
import ExtensionAPI from '../../core/ExtensionAPI.js';
export default function treeLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
