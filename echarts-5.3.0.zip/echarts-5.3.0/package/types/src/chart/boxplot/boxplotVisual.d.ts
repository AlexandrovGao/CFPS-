import GlobalModel from '../../model/Global.js';
import ExtensionAPI from '../../core/ExtensionAPI.js';
export default function boxplotVisual(ecModel: GlobalModel, api: ExtensionAPI): void;
