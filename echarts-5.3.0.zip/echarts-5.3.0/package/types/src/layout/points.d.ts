import { StageHandler } from '../util/types.js';
export default function pointsLayout(seriesType: string, forceStoreInTypedArray?: boolean): StageHandler;
